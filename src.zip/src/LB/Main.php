<?php

namespace LB;

use pocketmine\item\Item;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat;
use pocketmine\Player;
use pocketmine\level\sound\BlazeShootSound;
use pocketmine\level\Level;
use pocketmine\entity\Effect;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\level\Position;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\plugin\PluginBase as Base;

class Main extends Base implements Listener{
        public function onEnable(){
        $this->getLogger()->info("§aEnable");
		$this->getLogger()->info("§asuccessful §3Loaded ");
		$this->getLogger()->info("§9Done");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
	
	public function onCommand(CommandSender $sender, Command $command, $label, array $args){
            switch($command->getName()){
                case "lb";
				$player = $sender->getServer()->getPlayer($sender->getName());
								$rdps = mt_rand ( 1, 5 );
                                $item_rd = Item::get(19, 0, $rdps);
                                if ($player->getInventory()->canAddItem($item_rd)) {
                                    $player->getInventory()->addItem($item_rd);
                                    $sender->sendPopup("§6[LB] Fun $rdps §eLuckyBlock-о§a! :)");
									$this->getServer()->broadcastMessage("§l§c=§6=§e=§a=§b=§d=§c=§6=§e=§a=§b=§d=§c=§6=§8=§a=§b=§d=§c=§6=§e=§a=§8=§d=§c=§6=§e=§a=§b=§d=§c=§6=");
									$this->getServer()->broadcastMessage("§6[LB]  $rdps §eLuckyBlock §dPlugin §3v1.1.3 §5By: :§c ". $sender->getName(). "");
									$this->getServer()->broadcastMessage("§l§c=§6=§e=§a=§b=§d=§c=§6=§e=§a=§b=§d=§c=§6=§e=§a=§b=§d=§c=§6=§e=§a=§b=§d=§c=§6=§e=§a=§b=§d=§c=§6=");
                                    return;
                                } else {
                                    $sender->sendMessage("§6[LB] §a have fun §eLuckyBlock-ов§a! :(");
                                    return;
                                }
				
            }
        }
	
	
	

    public function onBreak(BlockBreakEvent $event){
        if($event->getPlayer()->hasPermission("randomdropus.cmd")){
            if($event->getBlock()->getId() === 14){
                $event->setDrops(array(Item::get(322)));
            }
            elseif($event->getBlock()->getId() === 15){
                $event->setDrops(array(Item::get(305)));
            }
			elseif($event->getBlock()->getId() === 19){
				//Items
				$i = mt_rand ( 1, 15 );
		if ($i == 1) {
			$item_id = 378;
		}
		elseif ($i == 2) {
			$item_id = 388;
		}
		elseif ($i == 3) {
			 $item_id = 266;
		}
		elseif ($i == 4) {
			$item_id = 384;
		}
		elseif ($i == 5) {
			$item_id = 264;
     }
     elseif ($i== 6) {
       $item_id = 322;
		}
     elseif ($i== 7) {
       $item_id = 297;
     }
     elseif ($i== 8) {
       $item_id = 413;
     }
     elseif ($i== 9) {
       $item_id = 261;
     }
      elseif ($i== 10) {
       $item_id = 262;
     }
      elseif ($i== 11) {
       $item_id = 259;
     }		
      elseif ($i== 12) {
       $item_id = 258;
     }
		  elseif ($i== 13) {
       $item_id = 288;
     }
       elseif ($i== 14) {
       $item_id = 311;
     }
     	elseif ($i== 15) {
       $item_id = 310;		
		}
		
		
		//amount
		$am = mt_rand ( 1, 15 );
		if ($am == 1) {
			$item_amount = 1;
		}
		elseif ($am == 2) {
			$item_amount = 1;
		}
		elseif ($am == 3) {
			 $item_amount = 1;
		}
		elseif ($am == 4) {
			$item_amount = 1;
		}
		elseif ($am == 5) {
			$item_amount = 2;
     }
      elseif ($am == 6) {
			$item_amount = 1;
     }
      elseif ($am == 7) {
			$item_amount = 1;
    }
      elseif ($am == 8) {
			$item_amount = 1;
    }
      elseif ($am == 9) {
			$item_amount = 1;
    }
       elseif ($am == 10) {
			$item_amount = 1;
     }
       elseif ($am == 11) {
			$item_amount = 1;
     }
       elseif ($am == 12) {
			$item_amount = 1;
     }
       elseif ($am == 13) {
			$item_amount = 1;
     }
       elseif ($am == 14) {
			$item_amount = 1;
     }
       elseif ($am == 15) {
			$item_amount = 1;
		}
		
		
		
		
                $event->setDrops(array(Item::get($item_id, 0, $item_amount)));
            }
        }
    }
	public function ItemHold(PlayerItemHeldEvent $ev){
		$player = $ev->getPlayer();
		if ($ev->getItem()->getID() === 19){
			
			$player->sendPopup("§l§a[§4Lucky§6Block§a] §e§lGood Luck...  §9:)");
		}
	}
    public function onDisable(){
        $this->getLogger()->info("§cDisable");
		$this->getLogger()->info("§aPlugin by §cYOUSEEFXCRAFT ");
		$this->getLogger()->info("§6Disabled");
    }
}
